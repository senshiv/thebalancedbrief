const swconf = {
  
    cacheName: 'chirpy-1751517433',resources: [
      '/assets/css/jekyll-theme-chirpy.css',
      '/',
      
        '/categories/',
      
        '/about/',
      
        '/archives/',
      
        '/blogs/',
      
        '/tags/',
      

      
      
    ],

    interceptor: {paths: [
        
      ],urlPrefixes: [
        
      ]
    },

    purge: false
  
};

